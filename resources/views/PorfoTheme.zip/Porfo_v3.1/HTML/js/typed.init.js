
if(document.getElementsByClassName('typed-five').length > 0) {
    var typed = new Typed('.typed-five', {
        stringsElement: '#typed-strings',
        typeSpeed: 200,
        loop: true,
        strings: [
            'Front-end developer', 'UX/UI designer', 'Products Designer',
        ],
    });
}

if(document.getElementsByClassName('typed-seven').length > 0) {
    var typed = new Typed('.typed-seven', {
        stringsElement: '#typed-strings',
        typeSpeed: 200,
        loop: true,
        strings: [
            'Minimalist', 'Modern', 'Creator', 'Professional',
        ],
    });
}